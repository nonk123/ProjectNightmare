#include <string>

std::wstring widen(std::string str);
std::string narrow(std::wstring wstr);
